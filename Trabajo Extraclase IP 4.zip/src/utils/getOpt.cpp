#include "./getOpt.hpp"
#include <iostream>

int getOpt(int max_opt)
{ return getOpt(max_opt, "Introduzca una opcion valida: "); }

int getOpt(int max_opt, const char sms[]){
    int opt=0;
    do{
        std::cout << sms;
        std::cin >> opt;
    }while(
            (opt > max_opt)
        ||  (opt < 0)
    );
    return opt;
}