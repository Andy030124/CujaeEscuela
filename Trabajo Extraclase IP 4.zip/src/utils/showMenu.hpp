#ifndef _SHOW_MENU_HPP_
#define _SHOW_MENU_HPP_
#include "../types/menu.hpp"
void showMenu(Menu m);

#endif 