#include "./showMenu.hpp"
#include <iostream>

void showMenu(Menu m){
    std::cout 
    << "-----\t"<<m.title<<"\t-----\n";

    for(int i=0; i < m.options_lenght; i++)
        std::cout << i+1 << ".\t" << m.options[i].opt_desc << '\n';
    
    std::cout << "0.\tSalir" << std::endl;

}