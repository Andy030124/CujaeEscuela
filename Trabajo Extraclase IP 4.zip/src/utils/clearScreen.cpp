#include "./clearScreen.hpp"
#include <cstdlib>

#ifdef _WIN32
    #define _CLS_COMMAND "cls"
#else
    #define _CLS_COMMAND "clear"
#endif

void cls(){ std::system(_CLS_COMMAND);}

