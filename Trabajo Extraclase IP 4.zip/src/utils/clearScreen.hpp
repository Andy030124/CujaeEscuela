#ifndef _CLS_SCREEN_HPP_
#define _CLS_SCREEN_HPP_
void cls();
#endif