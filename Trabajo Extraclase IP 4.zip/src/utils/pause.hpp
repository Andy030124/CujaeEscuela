#ifndef _UTILS_HPP_
#define _UTILS_HPP_

void pause();

#endif