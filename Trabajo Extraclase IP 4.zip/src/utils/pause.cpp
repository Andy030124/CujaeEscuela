#include <iostream>

void pause(){
    bool enter = false;
    std::cout << "\nPulsa Enter para continuar..." << std::endl;
    
    while (!enter) {
        if (
                std::cin.eof()
            ||  std::cin.get() == 10 // enter
        ) enter=true;
    }
    
    if( enter )
        std::cin.get();
}
