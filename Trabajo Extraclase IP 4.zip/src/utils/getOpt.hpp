#ifndef _GET_OPT_HPP_
#define _GET_OPT_HPP_

int getOpt(int max_opt);
int getOpt(int max_opt,const char[]);

#endif