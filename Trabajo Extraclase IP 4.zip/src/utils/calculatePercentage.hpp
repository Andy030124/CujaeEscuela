#ifndef _CALCULAR_PORCENTAJE_HPP_
#define _CALCULAR_PORCENTAJE_HPP_
#include "../types/trabajadores.hpp"

double calculatePercentage(const Trabajadores_t& ts, double pres);
double calculatePercentageGen(const Trabajadores_t& ts, double pres, genero_t g);

#endif