#include "./calculatePercentage.hpp"

double sumatoriaTotal(const Trabajadores_t& ts){
    double suma = 0.0;
    for(int i=0; i < ts._cantidad; i++)
        suma += ts._trabajadores[i]._salario;
    return suma;
}

double sumatoriaGen(const Trabajadores_t& ts, genero_t g){
    double suma = 0.0;
    for(int i=0; i < ts._cantidad; i++)
        if( ts._trabajadores[i]._genero == g )
            suma += ts._trabajadores[i]._salario;
    return suma;
}

double calculatePercentage(const Trabajadores_t& ts, double pres){
    return (
        sumatoriaTotal(ts)
        / pres
    ) * 100;
}

double calculatePercentageGen(const Trabajadores_t& ts, double pres, genero_t g){
    return (
        sumatoriaGen(ts, g)
        / pres
    ) * 100;

}


