#ifndef _MENU_TYPES_HPP_
#define _MENU_TYPES_HPP_

#define MAX_MENU_OPTIONS_LENGHT 1000
#define MAX_MENU_OPTIONS 10
#define MAX_MENU_TITLE_LENGHT 255

struct MenuOption{
    char opt_desc[MAX_MENU_OPTIONS_LENGHT];
};

struct Menu{
    char title[MAX_MENU_TITLE_LENGHT];
    MenuOption options[MAX_MENU_OPTIONS];
    int options_lenght=0;
};

Menu crearMenu(const char title[], MenuOption opts[], int lenght);

#endif