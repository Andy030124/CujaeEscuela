#include "./menu.hpp"
#include <cstring>

Menu crearMenu(const char title[], MenuOption opts[], int lenght){
    Menu m{};
    strncpy(m.title, title, MAX_MENU_TITLE_LENGHT);
    
    for(int i=0; (i < MAX_MENU_OPTIONS) && (i < lenght); i++){
        m.options[i] = opts[i];
        m.options_lenght++;
    }

    return m;
}