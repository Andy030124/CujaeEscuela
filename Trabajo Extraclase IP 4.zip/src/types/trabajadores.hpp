#ifndef _TRABAJADORES_HPP_
#define _TRABAJADORES_HPP_
#include "./trabajador.hpp"

#define TRABAJADORES_MAX 1000
using contador_t = int;
using grupo_t = Trabajador_t[TRABAJADORES_MAX];

struct Trabajadores_t{
    contador_t _cantidad{0};
    grupo_t _trabajadores;
};

bool trabjExiste(Trabajadores_t const& ts, Trabajador_t const& t);
bool addTrabj(Trabajadores_t& ts, const Trabajador_t& t);
bool quitTrabj(Trabajadores_t& ts, int idx);

void ordenarPorSalario(Trabajadores_t& ts);


#endif