#include "trabajadores.hpp"
#include <cstring>
#include <utility>
#include <iostream>

bool trabjExiste(Trabajadores_t const& ts, Trabajador_t const& t){
    for(int i=0; i < ts._cantidad; i++)
        if( strcmp(ts._trabajadores[i]._carnet, t._carnet) == 0 )
            return true;
    return false;
}

bool addTrabj(Trabajadores_t& ts, const Trabajador_t& t){
    if( ts._cantidad >= TRABAJADORES_MAX ) return false;
    if( trabjExiste(ts,t) )
        return false;

    ts._trabajadores[ts._cantidad++] = t;
    return true;
}

bool quitTrabj(Trabajadores_t& ts, int idx){
    if(
            (idx < 0)
        ||  (idx > ts._cantidad)
    ) return false;
    
    if( idx < ts._cantidad )
        ts._trabajadores[idx] = ts._trabajadores[ts._cantidad-1];

    --ts._cantidad;
    return true;
}

void ordenarPorSalario(Trabajadores_t& ts){
    int max=0;
    for(int i=0; i < ts._cantidad; i++){
        max = i;
        for(int j=i+1; j < ts._cantidad; j++){
            if( 
                    ts._trabajadores[max]._salario 
                <   ts._trabajadores[j]._salario 
            ){
                std::cout << "Ord " << j+1 << " > " << max+1 << "\n";
                max = j;
            }else{
                std::cout << "No Ord " << j+1 << '\n';
            }
        }
        if( max != i ){
            std::cout << "Swapping " << i << " -> " << max << std::endl;
            std::swap(ts._trabajadores[max], ts._trabajadores[i]);
        }
    }
}
