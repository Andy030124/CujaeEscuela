#ifndef _TRABAJADOR_HPP_
#define _TRABAJADOR_HPP_

using carnet_t = char[12];
using salario_t = double;

enum genero_t{
    Masculino,
    Femenino
};

struct Trabajador_t{
    carnet_t _carnet;
    salario_t _salario;
    genero_t _genero;
};

#endif