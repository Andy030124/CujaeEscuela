#include "menu/MenuPrincipal.hpp"

int main(){
    Trabajadores_t ts{};
    double presupuesto{0.0};
    
    runMenuPrincipal(ts, presupuesto);
    
    return 0;
}

