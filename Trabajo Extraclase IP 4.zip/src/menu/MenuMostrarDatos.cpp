#include "./MenuMostrarDatos.hpp"
#include <iostream>
#include "../mostrar/Mostrar.hpp"

#include "../utils/pause.hpp"
#include "../utils/getOpt.hpp"
#include "../utils/showMenu.hpp"
#include "../utils/clearScreen.hpp"

void runMenuMostrarDatos(const Trabajadores_t& ts, const double& pres){
    bool menuRun{true};

    MenuOption options[] = {
        "Mostrar Todos Los Datos",
        "Mostrar Datos De Hombres",
        "Mostrar Datos De Mujeres",
        "Mostrar Solo El Presupuesto",
        "Mostrar Porcentajes De Sueldos"
    };
    int options_lenght = sizeof(options) / sizeof(MenuOption);
    Menu mmd = crearMenu("MENU PRINCIPAL", options, options_lenght);

    while(menuRun){
        cls();
        showMenu(mmd);
        int opt = getOpt(options_lenght);
        cls();
        switch(opt){
            // salir
            case 0: {menuRun=false; break;}
            case 1: {
                MostrarTodo(ts, pres);
                break;
            }
            case 2: {
                MostrarHombres(ts);
                break;
            }
            case 3: {
                MostrarMujeres(ts);
                break;
            }
            case 4: {
                MostrarPresupuesto(pres);
                break;
            }
            case 5: {
                MostrarPorcentajePresupuesto(ts, pres);
                break;
            }
        }

        if( menuRun )
            pause();
    }

    std::cout << "\n\n" << std::endl;
}

