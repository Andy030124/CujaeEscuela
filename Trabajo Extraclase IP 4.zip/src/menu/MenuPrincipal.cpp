#include "./MenuPrincipal.hpp"
#include "./MenuMostrarDatos.hpp"

#include <iostream>
#include "../input/ObtenerDatos.hpp"

#include "../utils/pause.hpp"
#include "../utils/getOpt.hpp"
#include "../utils/showMenu.hpp"
#include "../utils/clearScreen.hpp"

void runMenuPrincipal(Trabajadores_t& ts, double& pres){
    bool menuRun{true};

    MenuOption options[] = {
        "Introducir Datos",
        "Mostrar Datos"
    };
    int options_lenght = sizeof(options) / sizeof(MenuOption);
    Menu mp = crearMenu("MENU PRINCIPAL", options, options_lenght);

    obtenerDatosTrabajadores(ts, pres);

    while(menuRun){
        cls();
        showMenu(mp);
        int opt = getOpt(options_lenght);
        cls();
        switch(opt){
            // Salir
            case 0 : {menuRun = false; break;}
            case 1 : {
                obtenerDatosTrabajadores(ts, pres);
                ordenarPorSalario(ts);
                break;
            }
            case 2 : {
                runMenuMostrarDatos(ts, pres);
                break;
            }
        }
    }

    std::cout << "\n\nSaliendo del Menu Principal!\n\tHasta Luego!\n";
    pause();
}
