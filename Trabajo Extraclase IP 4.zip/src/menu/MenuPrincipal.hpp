#ifndef _MENU_PRINCIPAL_HPP_
#define _MENU_PRINCIPAL_HPP_
#include "../types/trabajadores.hpp"

void runMenuPrincipal(Trabajadores_t& ts, double& pres);

#endif