#ifndef _MENU_MOSTRAR_DATOS_HPP_
#define _MENU_MOSTRAR_DATOS_HPP_
#include "../types/trabajadores.hpp"

void runMenuMostrarDatos( const Trabajadores_t& ts,  const double& pres);

#endif