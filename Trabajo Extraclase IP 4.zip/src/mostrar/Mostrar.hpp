#ifndef _MOSTRAR_DATOS_HPP_
#define _MOSTRAR_DATOS_HPP_
#include "../types/trabajadores.hpp"

void MostrarTodo(const Trabajadores_t& ts, double presupuesto);

void MostrarGenero(const Trabajadores_t& ts, genero_t g);
void MostrarHombres(const Trabajadores_t& ts);
void MostrarMujeres(const Trabajadores_t& ts);

void MostrarPresupuesto(double presupuesto);
void MostrarPorcentajePresupuesto(const Trabajadores_t& ts, double presupuesto);

#endif