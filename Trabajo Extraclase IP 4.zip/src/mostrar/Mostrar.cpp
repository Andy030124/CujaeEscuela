#include "./Mostrar.hpp"
#include "../utils/calculatePercentage.hpp"
#include <iostream>

void MostrarTrabajador(const Trabajador_t& t, int num){
    std::cout << "Trabajador #" << num+1 << '\n'
    << "Carnet -> " << t._carnet << '\n'
    << "Salario -> "<< t._salario<< '\n'
    << "Genero -> ";
    if( t._genero == Masculino )
        std::cout << "Masculino\n";
    else
        std::cout << "Femenino\n";
    std::cout << std::endl;
}

void MostrarTodo(const Trabajadores_t& ts, double presupuesto){
    for(int i=0; i < ts._cantidad; i++)
        MostrarTrabajador(ts._trabajadores[i], i);
    MostrarPresupuesto(presupuesto);
    MostrarPorcentajePresupuesto(ts, presupuesto);
}


void MostrarGenero(const Trabajadores_t& ts, genero_t g){
    int cshow = 0;
    for(int i=0; i < ts._cantidad; i++){
        if( ts._trabajadores[i]._genero != g ) continue;
        MostrarTrabajador(ts._trabajadores[i], i);
        cshow++;
    }

    if( cshow <= 0 ){
        std::cout << "No hay trabajador";
        if( g == genero_t::Femenino ) std::cout << "a";
        else std::cout << "e";

        std::cout << "s." << std::endl;
    }else{
        std::cout << "\nSe han mostrado " << cshow << std::endl;
    }
}

void MostrarHombres(const Trabajadores_t& ts)
{ MostrarGenero(ts, Masculino); }

void MostrarMujeres(const Trabajadores_t& ts)
{ MostrarGenero(ts, Femenino); }

void MostrarPresupuesto(double presupuesto){
    std::cout << "Se cuenta con un presupuesto de " << presupuesto << "$\n";
}

void MostrarPorcentajePresupuesto(const Trabajadores_t& ts, double presupuesto){
    if( ts._cantidad <= 0 ){
        std::cout << "No tienes Trabajadores. Tu presupuesto esta disponible al 100%\n";
        return;
    }

    std::cout 
    << "Los Salarios representan un " 
    << calculatePercentage(ts, presupuesto)
    << "%\nDe los cuales, los hombres " 
    << calculatePercentageGen(ts, presupuesto, genero_t::Masculino)
    << "% y las Mujeres "
    << calculatePercentageGen(ts, presupuesto, genero_t::Femenino)
    << "%" << std::endl;
}


