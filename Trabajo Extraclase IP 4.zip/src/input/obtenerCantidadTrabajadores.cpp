#include "./obtenerCantidadTrabajadores.hpp"
#include "../types/trabajadores.hpp"
#include <iostream>

int obtenerCantidadTrabajadores(){
    int cant=0;
    do{
        std::cout << "\nCantidad de Trabajadores: ";
        std::cin >> cant;
    }while(
            (cant <= 0)
        ||  (cant > TRABAJADORES_MAX)
    );
    return cant;
}