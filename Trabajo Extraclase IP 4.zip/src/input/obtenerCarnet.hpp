#ifndef _GET_CARNET_HPP_
#define _GET_CARNET_HPP_
#include "../types/trabajador.hpp"

void obtenerCarnet(carnet_t carnet_out);


#endif