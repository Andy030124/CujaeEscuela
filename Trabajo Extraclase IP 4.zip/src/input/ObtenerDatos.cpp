#include "./ObtenerDatos.hpp"

#include "./obtenerCarnet.hpp"
#include "./obtenerSalario.hpp"
#include "./obtenerCantidadTrabajadores.hpp"
#include "./obtenerPresupuesto.hpp"

#include <iostream>
#include <cstring>
#include <cctype>

int char_to_int(char c)
{return (int(c) - 30);}

genero_t deducirGenero(const Trabajador_t& t){
    genero_t gen{ Femenino };
    // 0 1 2 3 4 5 6 7 8 9 10 11
    // 0 3 0 1 2 4 6 6 6 2 5  \0 
    if( (char_to_int(t._carnet[9]) % 2) == 0 )
        gen = Masculino;
    
    return gen;
}

void registrarCarnet(Trabajadores_t const& trabjs, Trabajador_t& t){
    do{
        obtenerCarnet(t._carnet);
        if( !trabjExiste(trabjs,t) )
            break;
        std::cout << "Este carnet de identidad ya esta registrado\n\t porfavor introduzca uno nuevo.\n";
    }while( true );
}

void registrarGenero(Trabajador_t& t){
    t._genero = deducirGenero(t);
    std::cout << "Por tu carnet de identidad se dedujo que eres ";
    if(t._genero == Masculino){
        std::cout << "hombre";
    }else{
        std::cout << "mujer";
    }
    std::cout << "\n";
}

void obtenerDatosTrabajadores(Trabajadores_t& trabjs, double& presupuesto){
    trabjs._cantidad = 0;
    double presupuesto_minimo = 0.0;
    int cantidad = obtenerCantidadTrabajadores();
    Trabajador_t t{};
    
    for(int i=0; i < cantidad; i++){
        std::cout 
        << std::endl
        << "Obteniendo los datos del Trabajador #" << i+1 << ":\n";

        registrarCarnet(trabjs, t);
        registrarGenero(t);
        t._salario = obtenerSalario();

        if( ! addTrabj(trabjs, t) ){
            std::cout << "Ha ocurrido un error inesperado! (vuelva a ingresar los datos)\n";
            i--;
        }else{
            std::cout << "Trabajador #" << i+1 << " registrado correctamente!\n";
        }

        presupuesto_minimo+= t._salario;
    }
    std::cout 
    << "Se han ingresado los datos de " 
    << trabjs._cantidad << " trabajadores.\n";

    presupuesto = obtenerPresupuesto(presupuesto_minimo);
    
    ordenarPorSalario(trabjs);
}

