#ifndef _GET_DATOS_TRABAJADORES_HPP_
#define _GET_DATOS_TRABAJADORES_HPP_
#include "../types/trabajadores.hpp"

void obtenerDatosTrabajadores(Trabajadores_t& trabjs, double& presupuesto);

#endif