#ifndef _GET_CANT_TRABAJADORES_HPP_
#define _GET_CANT_TRABAJADORES_HPP_

int obtenerCantidadTrabajadores();

#endif