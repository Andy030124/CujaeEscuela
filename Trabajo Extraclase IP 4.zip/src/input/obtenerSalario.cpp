#include "./obtenerSalario.hpp"
#include <iostream>


double obtenerSalario(){
    double salario=0.0;

    do{
        std::cout << "Salario: ";
        std::cin >> salario;
    }while(salario <= 0.0);

    return salario;
}

