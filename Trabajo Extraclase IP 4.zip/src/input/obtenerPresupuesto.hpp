#ifndef _GET_PRESUPUESTO_HPP_
#define _GET_PRESUPUESTO_HPP_

double obtenerPresupuesto(double min);

#endif