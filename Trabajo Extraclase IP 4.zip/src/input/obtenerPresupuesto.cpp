#include "./obtenerPresupuesto.hpp"
#include <iostream>

double obtenerPresupuesto(double min){
    double p{0.0};
    do{
        std::cout << "Ingrese el presupuesto "
        << "para el pago de salarios "
        << "(minimo: " << min << "): ";
        std::cin >> p;

    }while(
            (p < min)
        ||  (p <= 0)
    );

    return p;
}