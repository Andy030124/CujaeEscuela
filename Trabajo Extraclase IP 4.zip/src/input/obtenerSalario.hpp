#ifndef _GET_SALARIO_HPP_
#define _GET_SALARIO_HPP_

double obtenerSalario();

#endif