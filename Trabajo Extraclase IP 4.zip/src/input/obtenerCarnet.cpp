#include "./obtenerCarnet.hpp"
#include <iostream>
#include <string>
#include <cctype>
#include <cstring>
#include <charconv>

#define MIN_DAY 1
#define MAX_DAY 31

#define MIN_MES 1
#define MAX_MES 12

#define MIN_YEAR 0
#define MAX_YEAR 99

bool verificarFecha(const carnet_t c){
    bool ret = true;

    long dia=0, mes=0, anyo=0;

    std::from_chars(c, &c[2], anyo, 10);
    std::from_chars(&c[2], &c[4], mes, 10);
    std::from_chars(&c[4], &c[6], dia, 10);

    if(
            (anyo < MIN_YEAR)
        ||  (anyo > MAX_YEAR)
    ) ret = false;
    if(
            (mes < MIN_MES)
        ||  (mes > MAX_MES)
    ) ret = false;

    if( dia < MIN_DAY ) ret = false;
    else{
        switch(mes){
            case 2: // febrero
            // año bisiesto
            if(
                (
                    (anyo % 4 == 0 && anyo % 100 != 0)
                && dia > 29
                )
                || dia > 28
            ) ret = false;
            break;
            // meses con 31 dias
            case 1:case 3:case 5:case 7:case 8:case 10:case 12:
                if( dia > 31 ) ret=false;
                break;
            // meses con 30 dias
            case 4:case 6:case 9:case 11:
            if( dia > 30 ) ret=false;
            break;
        }
    }

    return ret;
}

bool carnetValido(const carnet_t c){
    bool carnetValid = true;
    for(int i=0; (i < 11) && carnetValid; i++){
        carnetValid &= ( std::isdigit(c[i]) != 0 );
    }

    return (carnetValid && verificarFecha(c));
}

void obtenerCarnet(carnet_t carnet_out){
    std::string buffer{};
    carnet_t in = {};

    do{
        std::cout << "Carnet: ";
        std::cin >> buffer;

        if( buffer.length() < 11 )
            continue;
        
        strncpy(in, buffer.c_str(), 11);
    }while(!carnetValido(in));

    strncpy(carnet_out, in, 11);
}
